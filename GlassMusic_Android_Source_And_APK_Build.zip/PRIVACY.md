# Glass Music privacy

Glass Music is designed as an offline player. It does not request internet access, use analytics, sync a library to a server, or read anything other than the audio media metadata and files permission allows. Android controls the media-library permission. App settings, favorites and playlists are stored in local WebView storage on the device and are cleared on app data reset. Cover-art extraction uses Android MediaMetadataRetriever on local content URIs. No audio data is uploaded.

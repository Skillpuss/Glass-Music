# Glass Music — Android offline music player

An **original** local music player inspired by the floating, translucent iOS 26 Apple Music interface. Uses the device's native Android MediaStore and MediaPlayer, not an online streaming service. It is **not** an official Apple product and does not use Apple's proprietary code, brand, artwork, or assets.

## What's implemented

- Library scans actual audio files on device via `READ_MEDIA_AUDIO` (Android 13+) or legacy read permission
- Songs / albums / artists / favorites / user playlists / search / recent tracks
- Native MP3/AAC/M4A/FLAC/WAV/OGG playback as supported by Android's codecs
- Background playback foreground service with media notification, headset transport controls, metadata, and audio focus
- Play, pause, next/previous, seek, shuffle, repeat-one/all
- Embedded cover art via MediaMetadataRetriever (loaded lazily)
- iOS-inspired floating glass bottom navigation, translucent mini-player, full-screen ambient Now Playing UI
- Browser-only `index.html` preview can import and play selected local files via the file picker
- Offline and no analytics/network permissions

## Get an APK

The build environment in this chat does **not** contain the Android SDK and cannot access the SDK download servers, so I have **not** compiled or tested an APK here. This repository contains the complete app source plus a GitHub Actions workflow to build and produce the APK artifact.

**GitHub Actions (no Android Studio needed):** Upload all files to the root of a private or public GitHub repo. In **Actions** > **Build Glass Music APK**, choose **Run workflow**. When the build passes, open the run and download **GlassMusic-Android-APK**. Inside is `app-debug.apk`, which is signed with the Android debug keystore and installable. You may need to allow installation from unknown sources on your phone. Do not distribute a debug-key build for production.

**Android Studio:** Open this folder, sync Gradle, run **Build > Build APK(s)**. Install the generated `app/build/outputs/apk/debug/app-debug.apk` on your Galaxy S24 FE.

## Browser design preview

Open `app/src/main/assets/index.html` in a modern browser. The fictional preview songs are placeholders only; click **Import Music Files** and select your own audio files to play them in your browser. The Android build does not display fictional songs: it requests access to your actual device library instead.

## Known differences / limitations

- This recreates *parts of the visual language*, not pixel-perfect native Apple Liquid Glass refraction or Apple's proprietary animations.
- Apple Music streaming, Apple ID sync, DRM and Apple-exclusive features are not supported.
- Browser preview can only play files you explicitly select; full device library scanning is an Android-only feature.
- Favorites and playlists are saved locally to WebView storage; they are not cloud synchronized.
- Android version targetSdk 35/compileSdk 35; not tested on physical hardware yet.
- Playlist editing is basic. No synced LRC lyrics or queue rearranging yet.
- Android's playback session is used; on-device equalizer and route picker depend on Android system.

## Build notes

- Java 17, Android Gradle Plugin 8.9.2, Gradle 8.11.1, Android SDK 35.
- Requires `FOREGROUND_SERVICE_MEDIA_PLAYBACK` for media foreground services on modern Android.
- All HTML/CSS/JS is shipped in `app/src/main/assets/`; no network required.

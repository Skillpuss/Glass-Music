/* Glass Music: all rendering is offline; Android owns device playback and MediaStore access. */
(() => {
  'use strict';
  const native = typeof window.NativeMusic !== 'undefined';
  const $ = selector => document.querySelector(selector);
  const $$ = selector => [...document.querySelectorAll(selector)];
  const ICONS = {
    music:'<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    home:'<path d="m3 10 9-7 9 7v10a1 1 0 0 1-1 1H4a1 1 0 0 1-1-1V10Z"/><path d="M9 21v-7h6v7"/>',
    library:'<rect x="3" y="3" width="5" height="18" rx="1"/><rect x="10" y="3" width="5" height="18" rx="1"/><path d="m17 3 5 17"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="m16.5 16.5 5 5"/>',
    heart:'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z"/>',
    'heart-filled':'<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1.1-1.1a5.5 5.5 0 0 0-7.8 7.8L12 21l8.8-8.6a5.5 5.5 0 0 0 0-7.8Z" fill="currentColor"/>',
    play:'<path d="m8 4 13 8-13 8V4Z" fill="currentColor" stroke="none"/>',
    pause:'<rect x="5" y="3" width="5" height="18" rx="1.3" fill="currentColor" stroke="none"/><rect x="14" y="3" width="5" height="18" rx="1.3" fill="currentColor" stroke="none"/>',
    next:'<path d="m4 4 11 8-11 8V4Z" fill="currentColor" stroke="none"/><path d="M19 4v16" stroke-width="2.7"/>',
    previous:'<path d="m20 4-11 8 11 8V4Z" fill="currentColor" stroke="none"/><path d="M5 4v16" stroke-width="2.7"/>',
    shuffle:'<path d="m18 14 4 4-4 4"/><path d="m18 2 4 4-4 4"/><path d="M2 18h3c6 0 8-12 14-12h3"/><path d="M2 6h3c3.2 0 5 3.1 6 5"/><path d="M14 16c1 1.3 2.4 2 5 2h3"/>',
    repeat:'<path d="m17 2 4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/>',
    'repeat-one':'<path d="m17 2 4 4-4 4"/><path d="M3 11V9a3 3 0 0 1 3-3h15M7 22l-4-4 4-4"/><path d="M21 13v2a3 3 0 0 1-3 3H3"/><path d="M12 10v5m-2-3 2-2"/>',
    more:'<circle cx="5" cy="12" r="1.4" fill="currentColor"/><circle cx="12" cy="12" r="1.4" fill="currentColor"/><circle cx="19" cy="12" r="1.4" fill="currentColor"/>',
    chevron:'<path d="m9 18 6-6-6-6"/>',
    down:'<path d="m5 9 7 7 7-7"/>',
    up:'<path d="m5 15 7-7 7 7"/>',
    queue:'<path d="M3 5h18M3 11h18M3 17h12"/><path d="m18 16 4 3-4 3V16Z" fill="currentColor"/>',
    lyrics:'<path d="M4 4h16v12H8l-4 4V4Z"/><path d="M8 8h8M8 12h6"/>',
    speaker:'<path d="M5 9H2v6h3l6 5V4L5 9Z"/><path d="M15 9a5 5 0 0 1 0 6"/><path d="M18 6a9 9 0 0 1 0 12"/>',
    'speaker-low':'<path d="M5 9H2v6h3l6 5V4L5 9Z"/>',
    add:'<path d="M12 4v16M4 12h16"/>',
    check:'<path d="m4 12 5 5L20 6"/>',
    arrow:'<path d="M5 12h14m-6-6 6 6-6 6"/>',
    list:'<path d="M8 6h13M8 12h13M8 18h13"/><path d="M3 6h.1M3 12h.1M3 18h.1" stroke-width="3"/>',
    albums:'<rect x="3" y="3" width="18" height="18" rx="3"/><circle cx="12" cy="12" r="4"/><circle cx="12" cy="12" r="1" fill="currentColor"/>',
    artists:'<circle cx="12" cy="8" r="4"/><path d="M4 21c0-4 3-7 8-7s8 3 8 7"/>',
    download:'<path d="M12 3v12m-5-5 5 5 5-5M4 17v4h16v-4"/>',
    folder:'<path d="M3 5h7l2 3h9v12H3V5Z"/>',
    sparkles:'<path d="m12 2 2.5 7.5L22 12l-7.5 2.5L12 22l-2.5-7.5L2 12l7.5-2.5L12 2Z"/>',
    sort:'<path d="m4 7 4-4 4 4M8 4v16M14 17l4 4 4-4M18 20V4"/>',
    close:'<path d="M5 5 19 19M19 5 5 19"/>'
  };
  function icon(name, extra='') { return `<span class="ico ${extra}"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="1.8" aria-hidden="true">${ICONS[name] || ICONS.music}</svg></span>`; }
  function esc(s) { return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function storageGet(key, fallback) { try { const a=JSON.parse(localStorage.getItem(key)); return a == null ? fallback : a; } catch(e) { return fallback; } }
  function storageSet(key, val) { try { localStorage.setItem(key,JSON.stringify(val)); } catch(e) {} }
  const palettes = [ ['#e97f9c','#66436c'],['#657bc5','#30325b'],['#f0ad70','#9b4164'],['#779a96','#3a5c79'],['#bc7fbc','#423a82'],['#c98872','#703f44'],['#8cb9c4','#4b628e'],['#e28f95','#7a5676'],['#9c8daa','#4d5067'] ];
  function palette(song) { const k = String(song?.album || song?.title || ''); let n=0; for(let i=0;i<k.length;i++) n=(n*31 + k.charCodeAt(i))|0; return palettes[Math.abs(n)%palettes.length]; }
  function dur(ms) { const s=Math.max(0,Math.floor((Number(ms)||0)/1000)); return `${Math.floor(s/60)}:${String(s%60).padStart(2,'0')}`; }
  const demo = [
    ['Midnight Avenue','Nova Lane','Afterglow',238000],['Somewhere, Somehow','Noah Vale','The Open Sky',194000],
    ['Slow Motion','Aria Bloom','Slow Motion',202000],['Golden Hour','Mira Sol','Golden Hour',225000],
    ['Daydreams','Atlas Blue','Soft Focus',211000],['Stay a Little','Ever Quinn','Golden Hour',186000],
    ['City Lights','Nova Lane','Afterglow',208000],['The Way Home','Atlas Blue','Soft Focus',246000],
    ['Ocean Eyes','Mira Sol','Between Tides',219000],['Take My Time','Noah Vale','The Open Sky',223000],
  ].map((x,i)=>({id:i+1,title:x[0],artist:x[1],album:x[2],duration:x[3],added:Date.now()/1000-i*3600,albumId:i+1,demo:true}));
  const state = {
    tab:'home', category:'all', search:'', songs:[], permission:!native,
    isDemo:!native, loaded:false, displayCount:80, artistFilter:'', albumFilter:'',
    favorites:new Set(storageGet('glass_favorites',[]).map(String)),
    recent:storageGet('glass_recent',[]).map(String), playlists:storageGet('glass_playlists',[]),
    currentId:-1, playing:false, loading:false, position:0, duration:0, shuffle:false, repeat:0,
    playerOpen:false, queueOpen:false, seeking:false, artCache:{}, screenWas:'home',
  };
  const webAudio=$('#webAudio');
  const getSong=id => state.songs.find(s=>String(s.id)===String(id));
  const current=()=>getSong(state.currentId);
  function cover(song, size='sm', extra='') {
    const [a,b]=palette(song); const glyph=(song?.album || song?.title || 'M').split(/\s+/).slice(0,2).map(w=>w[0]||'').join('').toUpperCase();
    return `<div class="cover ${size} ${extra}" style="--art1:${a};--art2:${b}" ${song && !song.demo ? `data-art="${esc(song.id)}"` : ''}>
      <span class="cover-glyph">${esc(glyph)}</span></div>`;
  }
  function songRow(s, opts={}) {
    const isActive=String(s.id)===String(state.currentId);
    const like=state.favorites.has(String(s.id));
    return `<div class="song-row" role="button" tabindex="0" data-action="play" data-id="${esc(s.id)}">
      ${cover(s,'sm')}
      <div class="info"><div class="song-name ${isActive?'active':''}">${esc(s.title)}${isActive && state.playing?' ♪':''}</div><div class="song-artist">${esc(s.artist)} · ${esc(s.album)}</div></div>
      <div class="row-end"><span class="time">${s.duration?dur(s.duration):''}</span><button type="button" data-action="favorite" data-id="${esc(s.id)}" aria-label="${like?'Remove from favorites':'Add to favorites'}">${icon(like?'heart-filled':'heart')}</button></div>
    </div>`;
  }
  function miniMarkup() {
    const s=current(); if (!s) return '';
    return `${cover(s,'sm')}<div class="mini-info"><div class="mini-title">${esc(s.title)}</div><div class="mini-artist">${esc(s.artist)}</div></div>
    <button class="mini-control" data-action="toggle" aria-label="${state.playing?'Pause':'Play'}">${icon(state.playing?'pause':'play')}</button>
    <button class="mini-control next" data-action="next" aria-label="Next">${icon('next')}</button>
    <div class="mini-progress"><div id="miniBar"></div></div>`;
  }
  function navMarkup() { return [['home','home','Home'],['library','library','Library'],['favorites','heart','Favorites']].map(([id,i,title])=>`<button data-nav="${id}" class="nav-item ${state.tab===id?'active':''}" aria-label="${title}">${icon(i)}<span>${title}</span></button>`).join(''); }
  function renderHeader() {
    const titles={home:'Listen Now',library:'Library',favorites:'Favorites',search:'Search'};
    $('#header').innerHTML=`<div class="top-line"><div class="brand-mark"><span class="mark">${icon('music')}</span> GLASS MUSIC</div>
      <div class="header-actions"><button class="circle-btn" type="button" data-action="rescan" title="Refresh library">${icon('sort')}</button><div class="avatar" aria-hidden="true">G</div></div></div>
      <h1 class="page-title">${titles[state.tab]}</h1>
      <p class="page-subtitle">${state.tab==='home'?'Your soundtrack, beautifully yours.':state.tab==='library'?'Everything you love, all in one place.':state.tab==='search'?'Find your next favorite.':'The songs you keep close.'}</p>`;
  }
  function previewNote() { return `<div class="preview-note">${icon('sparkles')}<div>${native?'Allow audio access to play music stored on your device.':'Design preview with fictional titles. <strong>Import your own audio files to listen.</strong>'}</div></div>`; }
  function empty(title,desc,buttonLabel,action) { return `<div class="empty-state"><div class="empty-symbol">${icon('music')}</div><h3>${title}</h3><p>${desc}</p><button class="primary-button" data-action="${action}">${buttonLabel}</button></div>`; }
  function nothingYet() {
    if (native && !state.permission) return empty('Your music is waiting','Allow Glass Music to see your local audio collection. It never uploads any songs.','Allow Music Access','permission');
    return empty('Your library is empty','Add music files to your phone and come back to enjoy your collection offline.','Scan Music Again','rescan');
  }
  function sectionTop(title, action='',label='See All') { return `<div class="section-top"><h2 class="section-title">${esc(title)}</h2>${action?`<button class="section-action" data-action="${action}">${label} ›</button>`:''}</div>`; }
  function albumGroups(songs=state.songs) {
    const map=new Map();
    for(const s of songs) { const k=s.album+'|'+s.artist; if(!map.has(k)) map.set(k,{title:s.album,artist:s.artist,songs:[],first:s}); map.get(k).songs.push(s); }
    return [...map.values()];
  }
  function albumTiles(groups) { return `<div class="horizontal-scroll">${groups.map(g=>`<button class="album-tile" data-action="openAlbum" data-album="${esc(g.title)}" data-artist="${esc(g.artist)}">${cover(g.first,'lg')}<div class="album-name">${esc(g.title)}</div><div class="album-artist">${esc(g.artist)}</div></button>`).join('')}</div>`; }
  function homeView() {
    const tracks=state.songs;
    const recent=state.recent.map(getSong).filter(Boolean);
    const picks=recent.length ? recent : tracks.slice(0,6);
    const albums=albumGroups(tracks).slice(0,12);
    return `${(state.isDemo || (native && !state.permission)) ? previewNote():''}
      <div class="hero"><button class="feature" data-action="playAll">
        <div class="overline">YOUR DAILY SOUNDTRACK</div><div class="feature-title">Every song.<br>Every feeling.</div>
        <div class="feature-caption">A beautiful home for the music that's already yours.</div><span class="feature-action">${icon('play')} PLAY YOUR LIBRARY</span></button>
        <button class="feature secondary" data-action="shuffleAll"><div class="overline">JUST PRESS PLAY</div><div class="feature-title">Let the music<br>find you.</div>
        <div class="feature-caption">Rediscover a track you haven't heard in a while.</div><span class="feature-action">${icon('shuffle')} SHUFFLE SONGS</span></button></div>
      ${tracks.length ? `${sectionTop('Recently Played','viewSongs')}<div class="song-list">${picks.slice(0,4).map(s=>songRow(s)).join('')}</div>
      ${sectionTop('Your Albums','viewAlbums')}${albumTiles(albums)}` : nothingYet()}
      ${!native ? `<div class="list-action-row"><button class="list-action primary" data-action="import">${icon('add')} Import Music Files</button></div>` : ''}
    `;
  }
  function songListContent(songs, max=state.displayCount) {
    return `<div class="song-list">${songs.slice(0,max).map(s=>songRow(s)).join('')}</div>${songs.length>max?`<div class="list-action-row"><button class="list-action" data-action="loadMore">Load More (${songs.length-max} remaining)</button></div>`:''}`;
  }
  function libraryView() {
    if (!state.songs.length) return nothingYet();
    const cats=[['all','music','Songs'],['albums','albums','Albums'],['artists','artists','Artists'],['playlists','list','Playlists']];
    const catGrid=`<div class="category-list">${cats.map(([id,ico,name])=>`<button class="category ${state.category===id?'selected':''}" data-cat="${id}">${icon(ico)}<span>${name}</span></button>`).join('')}</div>`;
    let body='';
    if (state.category==='all') body=`${sectionTop(`Songs · ${state.songs.length}`)}<div class="list-action-row"><button class="list-action primary" data-action="playAll">${icon('play')} Play</button><button class="list-action" data-action="shuffleAll">${icon('shuffle')} Shuffle</button></div>${songListContent(state.songs)}`;
    if (state.category==='albums') {
      const groups=albumGroups(); body=sectionTop(`Albums · ${groups.length}`)+`<div class="horizontal-scroll" style="flex-wrap:wrap;overflow:visible;margin:0;padding:0;gap:16px;">${groups.map(g=>`<button class="album-tile" style="width:calc(50% - 8px);max-width:175px" data-action="openAlbum" data-album="${esc(g.title)}" data-artist="${esc(g.artist)}">${cover(g.first,'lg')}<div class="album-name">${esc(g.title)}</div><div class="album-artist">${esc(g.artist)}</div></button>`).join('')}</div>`;
    }
    if (state.category==='artists') {
      const groups=new Map();for(const s of state.songs){if(!groups.has(s.artist))groups.set(s.artist,[]); groups.get(s.artist).push(s);}
      body=sectionTop(`Artists · ${groups.size}`)+[...groups.entries()].map(([name,songs])=>{const p=palette(songs[0]);return `<button class="artist-row" style="width:100%;text-align:left" data-action="openArtist" data-artist="${esc(name)}"><span class="artist-circle" style="--art1:${p[0]};--art2:${p[1]}">${esc(name.slice(0,1).toUpperCase())}</span><span class="info"><strong>${esc(name)}</strong><div>${songs.length} songs</div></span>${icon('chevron')}</button>`;}).join('');
    }
    if (state.category==='playlists') body=playlistView();
    return `${catGrid}${body}`;
  }
  function playlistView() {
    return `${sectionTop('Your Playlists')}<div class="list-action-row"><button class="list-action primary" data-action="newPlaylist">${icon('add')} New Playlist</button></div>
    ${state.playlists.length ? state.playlists.map((p,i)=>{const songs=p.ids.map(getSong).filter(Boolean);return `<button class="artist-row" style="width:100%;text-align:left" data-action="openPlaylist" data-index="${i}">${songs.length?cover(songs[0],'sm'):`<span class="artist-circle" style="--art1:#eaa2b9;--art2:#875d83">${icon('list')}</span>`}<span class="info"><strong>${esc(p.name)}</strong><div>${songs.length} songs</div></span>${icon('chevron')}</button>`;}).join(''):empty('Make your first playlist','Organize the tracks you love into a personal collection.','Create Playlist','newPlaylist')}`;
  }
  function detailView() {
    let tracks=[],heading='',subtitle='';
    if(state.artistFilter) { heading=state.artistFilter; tracks=state.songs.filter(s=>s.artist===state.artistFilter); subtitle='Artist'; }
    else if(state.albumFilter) { const [album,artist]=state.albumFilter.split('\u0001');heading=album; subtitle=artist; tracks=state.songs.filter(s=>s.album===album&&s.artist===artist); }
    else if(state.playlistIndex!=null) { const p=state.playlists[state.playlistIndex]; if(p){heading=p.name;subtitle='Playlist';tracks=p.ids.map(getSong).filter(Boolean);} }
    return `<button class="soft-pill" data-action="backToLibrary">‹ Library</button>
       <div style="display:flex;gap:18px;margin-top:20px;align-items:center">${tracks.length?cover(tracks[0],'sm'):''}<div><div style="font-size:25px;font-weight:820;letter-spacing:-1px">${esc(heading)}</div><div style="color:#8c8996;font-size:12px;margin-top:5px">${esc(subtitle)} · ${tracks.length} songs</div></div></div>
       <div class="list-action-row"><button class="list-action primary" data-action="playFiltered">${icon('play')} Play</button><button class="list-action" data-action="shuffleFiltered">${icon('shuffle')} Shuffle</button></div>
       ${songListContent(tracks)}
       ${state.playlistIndex!=null?`<div class="list-action-row"><button class="list-action" data-action="addToPlaylist" data-index="${state.playlistIndex}">${icon('add')} Add Songs</button></div>`:''}`;
  }
  function filteredSongs() {
    if (state.artistFilter) return state.songs.filter(s=>s.artist===state.artistFilter);
    if (state.albumFilter) { const [a,b]=state.albumFilter.split('\u0001');return state.songs.filter(s=>s.album===a&&s.artist===b); }
    if (state.playlistIndex!=null) return (state.playlists[state.playlistIndex]?.ids||[]).map(getSong).filter(Boolean);
    return state.songs;
  }
  function favoriteView() {
    const songs=state.songs.filter(s=>state.favorites.has(String(s.id)));
    if(!songs.length) return empty('No favorites yet','Tap the heart beside a song to keep it close.','Explore Songs','viewSongs');
    return `${sectionTop(`Favorite Songs · ${songs.length}`)}<div class="list-action-row"><button class="list-action primary" data-action="playFavorites">${icon('play')} Play Favorites</button></div>${songListContent(songs)}`;
  }
  function searchView() {
    const query=state.search.trim().toLocaleLowerCase();
    const results=query ? state.songs.filter(s=>[s.title,s.artist,s.album].some(v=>v.toLocaleLowerCase().includes(query))) : [];
    return `<div class="search-box">${icon('search')}<input id="searchInput" type="search" placeholder="Artists, songs, albums" autocomplete="off" value="${esc(state.search)}" />${state.search?`<button data-action="clearSearch" aria-label="Clear">${icon('close')}</button>`:''}</div>
    ${query ? results.length?`${sectionTop(`${results.length} Results`)}${songListContent(results)}`:empty('Nothing found','Try a different song, artist, or album name.','Clear Search','clearSearch')
    : `<div class="section-top"><h2 class="section-title">Explore your music</h2></div><div class="category-list">${[['Songs','music'],['Artists','artists'],['Albums','albums'],['Favorites','heart']].map(([t,ic])=>`<button class="category" data-action="searchCategory" data-cat="${t.toLowerCase()}">${icon(ic)}${t}</button>`).join('')}</div>${sectionTop('Recently Added')}${songListContent([...state.songs].sort((a,b)=>b.added-a.added).slice(0,8))}`}`;
  }
  function render(keepScroll=false) {
    const content=$('#content'),top=keepScroll?content.scrollTop:0;
    renderHeader(); $('#navPill').innerHTML=navMarkup(); $('#searchNavIcon').innerHTML=icon('search');
    $('.search-pill').classList.toggle('active',state.tab==='search');
    content.innerHTML=state.tab==='home'?homeView():state.tab==='library'?(state.artistFilter || state.albumFilter || state.playlistIndex!=null?detailView():libraryView()):state.tab==='favorites'?favoriteView():searchView();
    content.scrollTop=top;
    if(state.tab==='search' && state.focusSearch){$('#searchInput')?.focus();state.focusSearch=false;}
    updateMini(); hydrateArtwork();
  }
  function updateMini() {
    const mini=$('#miniPlayer'),s=current(); mini.classList.toggle('hidden',!s);
    if(!s) return;
    const existing=mini.dataset.song;
    if(existing!==String(s.id)) {mini.innerHTML=miniMarkup();mini.dataset.song=String(s.id);hydrateArtwork();}
    const b=mini.querySelector('[data-action="toggle"]');
    if(b) b.innerHTML=icon(state.playing?'pause':'play');
    const bar=$('#miniBar'); if(bar) bar.style.width=`${Math.min(100,100*state.position/(state.duration||s.duration||1))}%`;
  }
  let artObserver = null;
  function hydrateArtwork() {
    if (artObserver) artObserver.disconnect();
    if (!native) return;
    artObserver = new IntersectionObserver(entries=>{
      for(const entry of entries){if(!entry.isIntersecting)continue;
        const node=entry.target; artObserver.unobserve(node);
        const id=Number(node.dataset.art), song=getSong(id),key=String(song?.albumId??id);
        if(!song)return;
        if (Object.hasOwn(state.artCache,key)) {if(state.artCache[key])applyArtwork(node,state.artCache[key]);continue;}
        setTimeout(()=>{
          try {let src=NativeMusic.getArtwork(id);state.artCache[key]=src||'';
            if(src) $$(`[data-art="${id}"]`).forEach(el=>applyArtwork(el,src));
          } catch(e) { state.artCache[key]=''; }
        },30);
      }
    },{rootMargin:'110px'});
    $$('[data-art]').forEach(node=>{ const song=getSong(node.dataset.art), key=String(song?.albumId??node.dataset.art);if(state.artCache[key])applyArtwork(node,state.artCache[key]);else artObserver.observe(node); });
  }
  function applyArtwork(node,src) { if(!node.querySelector('img')){const img=document.createElement('img');img.src=src;img.alt='';img.loading='lazy';node.appendChild(img);} }
  function updatePlayerHtml() {
    if(!state.playerOpen)return;
    const s=current();if(!s)return;
    const [a,b]=palette(s);const liked=state.favorites.has(String(s.id));
    const el=$('#player');el.innerHTML=`<div class="player-ambient" style="--art1:${a};--art2:${b}"></div>
    <div class="player-inner"><div class="player-top"><button class="player-chevron" data-action="closePlayer" aria-label="Close player">${icon('down')}</button>
      <div class="player-head"><small>NOW PLAYING</small><strong>Glass Music</strong></div><button class="player-more" data-action="showOptions" aria-label="More options">${icon('more')}</button></div>
      <div class="player-art-zone">${cover(s,'lg',state.playing?'playing':'')}</div>
      <div class="player-details"><div class="player-metadata"><div class="player-titles"><h2>${esc(s.title)}</h2><p>${esc(s.artist)}</p></div><button class="player-like ${liked?'liked':''}" data-action="favorite" data-id="${esc(s.id)}" aria-label="Favorite">${icon(liked?'heart-filled':'heart')}</button></div>
      <input id="seekSlider" class="seek" type="range" min="0" max="${Math.max(1,state.duration||s.duration)}" value="${state.position}" style="--pct:${100*state.position/(state.duration||s.duration||1)}%" aria-label="Playback position" />
      <div class="time-labels"><span id="elapsed">${dur(state.position)}</span><span id="remaining">-${dur((state.duration||s.duration)-state.position)}</span></div>
      <div class="transport"><button class="mode ${state.shuffle?'on':''}" data-action="shuffle" aria-label="Shuffle">${icon('shuffle')}</button>
        <button data-action="previous" aria-label="Previous song">${icon('previous')}</button>
        <button class="main-play" data-action="toggle" aria-label="${state.playing?'Pause':'Play'}">${icon(state.playing?'pause':'play')}</button>
        <button data-action="next" aria-label="Next song">${icon('next')}</button>
        <button class="mode ${state.repeat?'on':''}" data-action="repeat" aria-label="Repeat">${icon(state.repeat===2?'repeat-one':'repeat')}</button></div>
      <div class="player-volume">${icon('speaker-low')}<input type="range" class="volume-slider" id="volumeSlider" min="0" max="1" value="${webAudio.volume}" step=".01" aria-label="Volume">${icon('speaker')}</div>
      <div class="player-bottom"><button data-action="lyrics" aria-label="Lyrics">${icon('lyrics')}</button><button data-action="queue" aria-label="Up Next">${icon('queue')}</button><button data-action="showOptions" aria-label="More options">${icon('more')}</button></div></div></div>`;
    hydrateArtwork();
  }
  function updatePlayerProgress() {
    const slider=$('#seekSlider'); if(slider&&!state.seeking){slider.max=Math.max(1,state.duration);slider.value=state.position;slider.style.setProperty('--pct',`${100*state.position/(state.duration||1)}%`);}
    const elapsed=$('#elapsed'), remaining=$('#remaining');if(elapsed)elapsed.textContent=dur(state.position);if(remaining)remaining.textContent='-'+dur(state.duration-state.position);
  }
  function showPlayer() {if(!current()){toast('Choose a song first');return;}state.playerOpen=true;$('#player').classList.add('open');$('#player').setAttribute('aria-hidden','false');updatePlayerHtml();}
  function closePlayer() {state.playerOpen=false;state.queueOpen=false;$('#player').classList.remove('open');$('#player').setAttribute('aria-hidden','true');$('#queueSheet').classList.remove('open');}
  function showQueue() {
    const i=state.songs.findIndex(s=>String(s.id)===String(state.currentId));
    const arr=i>=0?[...state.songs.slice(i+1),...state.songs.slice(0,i)]:state.songs;
    $('#queueSheet').innerHTML=`<div class="queue-handle"></div><div class="queue-heading"><h2>Playing Next</h2><button class="circle-btn" data-action="closeQueue">${icon('close')}</button></div>
      <p style="color:#9b94a1;font-size:12px;margin-bottom:15px">${arr.length} songs in your library</p>${songListContent(arr,35)}`;
    state.queueOpen=true;$('#queueSheet').classList.add('open');hydrateArtwork();
  }
  let toastTimer;
  function toast(message) {const el=$('#toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600);}
  function play(s) {
    if(!s)return;
    if(s.demo) {toast('Import music files to start listening');return;}
    state.currentId=s.id;state.position=0;state.duration=s.duration;state.playing=true;
    state.recent=[String(s.id),...state.recent.filter(id=>id!==String(s.id))].slice(0,30);storageSet('glass_recent',state.recent);
    if(native) {try{NativeMusic.play(Number(s.id));}catch(e){toast('Could not play this song');}}
    else {webAudio.src=s.url;webAudio.play().catch(()=>toast('Could not play this audio file'));}
    render(true); if(state.playerOpen)updatePlayerHtml();
  }
  function togglePlay() {
    if(!current())return toast('Select a song');
    const willPlay=!state.playing;state.playing=willPlay;
    if(native) {try {if(willPlay)NativeMusic.resume();else NativeMusic.pause();}catch(e){} }
    else {if(willPlay)webAudio.play().catch(()=>{});else webAudio.pause();}
    updateMini();updatePlayerHtml();
  }
  function step(direction) {
    if(native){try {if(direction===1)NativeMusic.next();else NativeMusic.previous();}catch(e){}return;}
    let i=state.songs.findIndex(s=>String(s.id)===String(state.currentId));
    if(direction===-1 && state.position>3000) {webAudio.currentTime=0;return;}
    if(state.shuffle) i=Math.floor(Math.random()*state.songs.length); else i=(i+direction+state.songs.length)%state.songs.length;
    play(state.songs[i]);
  }
  function setTab(tab) {state.tab=tab;state.category='all';state.artistFilter='';state.albumFilter='';state.playlistIndex=null;state.displayCount=80;state.focusSearch=(tab==='search');render();}
  function toggleFavorite(id) {const key=String(id);if(state.favorites.has(key))state.favorites.delete(key);else state.favorites.add(key);storageSet('glass_favorites',[...state.favorites]);toast(state.favorites.has(key)?'Added to Favorites':'Removed from Favorites');render(true);updatePlayerHtml();}
  function rescan() {
    if(!native){$('#filePicker').click();return;}
    if(!state.permission){NativeMusic.requestPermission();return;}
    toast('Refreshing your library…');NativeMusic.rescan();
  }
  function refreshLibrary() {
    if(!native)return;
    try {
      state.permission=NativeMusic.hasPermission();
      state.songs=state.permission?JSON.parse(NativeMusic.getSongs()):[];
      state.loaded=true; state.isDemo=false;render(true);
    } catch(e) {toast('Unable to load your library');}
  }
  function refreshPlayback() {
    if(!native)return;
    try {
      const p=JSON.parse(NativeMusic.getState());
      const changed=String(state.currentId)!==String(p.id);
      state.currentId=p.id;state.playing=!!p.playing;state.loading=!!p.loading;
      state.position=p.position||0;state.duration=p.duration||0;state.shuffle=!!p.shuffle;state.repeat=p.repeat||0;
      if(p.error && p.error!==state.lastError){toast(p.error);state.lastError=p.error;}
      if(changed) {updateMini();if(state.playerOpen)updatePlayerHtml();}
      else {updateMini();updatePlayerProgress();const btn=$('#player .main-play');if(btn)btn.innerHTML=icon(state.playing?'pause':'play');}
    } catch(e){}
  }
  // Tiny ID3v2 text metadata decoder for browser preview imports (native uses MediaStore).
  async function readID3(file) {
    const info={};if(!/\.mp3$/i.test(file.name))return info;
    try {
      const a=new Uint8Array(await file.slice(0,Math.min(512000,file.size)).arrayBuffer());
      if(String.fromCharCode(...a.slice(0,3))!=='ID3')return info;
      const size=(a[6]<<21)|(a[7]<<14)|(a[8]<<7)|a[9],v=a[3];let pos=10;
      const decode=(bytes,enc)=>{
        if(enc===1||enc===2){ const little=enc===1 && bytes[0]===255; let off=enc===1&&((bytes[0]===255&&bytes[1]===254)||(bytes[0]===254&&bytes[1]===255))?2:0;let out='';for(let z=off;z+1<bytes.length;z+=2){let c=little ? bytes[z]+bytes[z+1]*256 : bytes[z]*256+bytes[z+1];if(c===0)break;out+=String.fromCharCode(c);}return out; }
        return new TextDecoder(enc===3?'utf-8':'iso-8859-1').decode(bytes).replace(/\0.*$/,'');
      };
      while(pos+10<Math.min(a.length,size+10)){
        const tag=String.fromCharCode(...a.slice(pos,pos+4));if(!/^T[A-Z0-9]{3}$/.test(tag))break;
        const n=v===4?(a[pos+4]<<21)|(a[pos+5]<<14)|(a[pos+6]<<7)|a[pos+7]:(a[pos+4]*0x1000000+a[pos+5]*65536+a[pos+6]*256+a[pos+7]);
        if(n<=0||pos+n+10>a.length)break;
        if(['TIT2','TPE1','TALB'].includes(tag))info[{TIT2:'title',TPE1:'artist',TALB:'album'}[tag]]=decode(a.slice(pos+11,pos+10+n),a[pos+10]).trim();
        pos+=10+n;
      }
    } catch(e){}return info;
  }
  $('#filePicker').addEventListener('change',async e=>{
    const files=[...e.target.files];if(!files.length)return;
    const next=[];for(let i=0;i<files.length;i++){
      const f=files[i],meta=await readID3(f);
      next.push({id:'file'+Date.now()+i,title:meta.title||f.name.replace(/\.[^.]+$/,''),artist:meta.artist||'Unknown Artist',album:meta.album||'Imported Music',
        duration:0,added:Math.floor(Date.now()/1000),albumId:Date.now()+i,url:URL.createObjectURL(f)});
    }
    for(const s of state.songs) if(s.url) URL.revokeObjectURL(s.url);
    state.songs=next;state.isDemo=false;state.currentId=-1;state.loaded=true;state.tab='library';state.category='all';render();
    toast(`${files.length} local audio file${files.length===1?'':'s'} added`);
    e.target.value='';
  });
  webAudio.addEventListener('timeupdate',()=>{if(native)return;state.position=webAudio.currentTime*1000;state.duration=webAudio.duration*1000||0;updateMini();updatePlayerProgress();});
  webAudio.addEventListener('loadedmetadata',()=>{if(native)return;const s=current();if(s)s.duration=webAudio.duration*1000;state.duration=webAudio.duration*1000;});
  webAudio.addEventListener('ended',()=>{if(native)return;if(state.repeat===2){webAudio.currentTime=0;webAudio.play();}else{state.playing=false;step(1);}});
  // Browser and Android actions. Event delegation preserves player state across renders.
  document.addEventListener('click',e=>{
    const nav=e.target.closest('[data-nav]');if(nav){setTab(nav.dataset.nav);return;}
    const el=e.target.closest('[data-action]');if(!el){if(e.target.closest('#miniPlayer'))showPlayer();return;}
    const action=el.dataset.action,id=el.dataset.id;
    switch(action){
      case 'permission':native?NativeMusic.requestPermission():$('#filePicker').click();break;
      case 'import':$('#filePicker').click();break;
      case 'rescan':rescan();break;
      case 'play':play(getSong(id));break;
      case 'toggle':togglePlay();break;
      case 'next':step(1);break;
      case 'previous':step(-1);break;
      case 'favorite':toggleFavorite(id);break;
      case 'playAll':{const x=state.songs.find(s=>!s.demo);if(x)play(x);else toast('Import your audio files to begin');break;}
      case 'shuffleAll':{const all=state.songs.filter(s=>!s.demo);if(all.length){state.shuffle=true;if(native)NativeMusic.shuffle(true);play(all[Math.floor(Math.random()*all.length)]);}else toast('Import your audio files to begin');break;}
      case 'playFavorites':{const s=state.songs.find(t=>state.favorites.has(String(t.id)));if(s)play(s);break;}
      case 'playFiltered':{const s=filteredSongs()[0];if(s)play(s);break;}
      case 'shuffleFiltered':{const list=filteredSongs();if(list.length)play(list[Math.floor(Math.random()*list.length)]);break;}
      case 'viewSongs':setTab('library');break;
      case 'viewAlbums':setTab('library');state.category='albums';render();break;
      case 'openAlbum':state.tab='library';state.albumFilter=el.dataset.album+'\u0001'+el.dataset.artist;state.artistFilter='';state.playlistIndex=null;render();break;
      case 'openArtist':state.tab='library';state.artistFilter=el.dataset.artist;state.albumFilter='';state.playlistIndex=null;render();break;
      case 'openPlaylist':state.tab='library';state.artistFilter='';state.albumFilter='';state.playlistIndex=Number(el.dataset.index);render();break;
      case 'backToLibrary':state.artistFilter='';state.albumFilter='';state.playlistIndex=null;render();break;
      case 'clearSearch':state.search='';render();state.focusSearch=true;$('#searchInput')?.focus();break;
      case 'searchCategory':if(el.dataset.cat==='favorites')setTab('favorites');else{setTab('library');state.category=el.dataset.cat==='songs'?'all':el.dataset.cat;render();}break;
      case 'loadMore':state.displayCount+=80;render(true);break;
      case 'newPlaylist':{const name=prompt('Name your playlist');if(name && name.trim()){state.playlists.push({name:name.trim().slice(0,55),ids:[]});storageSet('glass_playlists',state.playlists);render(true);toast('Playlist created');}break;}
      case 'addToPlaylist':{const idx=Number(el.dataset.index);const name=prompt('Enter the exact song title to add');const song=state.songs.find(s=>s.title.toLowerCase()===String(name||'').toLowerCase());if(song && state.playlists[idx]){const ids=state.playlists[idx].ids;if(!ids.some(i=>String(i)===String(song.id)))ids.push(String(song.id));storageSet('glass_playlists',state.playlists);render(true);toast('Added to playlist');}else toast('Song not found');break;}
      case 'closePlayer':closePlayer();break;
      case 'queue':showQueue();break;
      case 'closeQueue':state.queueOpen=false;$('#queueSheet').classList.remove('open');break;
      case 'lyrics':toast('Lyrics are not available for this local file');break;
      case 'showOptions':toast('Your music stays private and offline');break;
      case 'shuffle':state.shuffle=!state.shuffle;if(native)NativeMusic.shuffle(state.shuffle);updatePlayerHtml();toast(state.shuffle?'Shuffle On':'Shuffle Off');break;
      case 'repeat':state.repeat=(state.repeat+1)%3;if(native)NativeMusic.repeat(state.repeat);updatePlayerHtml();toast(['Repeat Off','Repeat All','Repeat One'][state.repeat]);break;
    }
  });
  document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(state.queueOpen){state.queueOpen=false;$('#queueSheet').classList.remove('open');}else if(state.playerOpen)closePlayer();}
    if((e.key==='Enter'||e.key===' ')&&e.target.classList.contains('song-row')){e.preventDefault();play(getSong(e.target.dataset.id));}
    if(e.code==='Space'&&e.target.tagName!=='INPUT'){e.preventDefault();togglePlay();}
  });
  document.addEventListener('input',e=>{
    if(e.target.id==='searchInput') {
      state.search=e.target.value;
      const pos=e.target.selectionStart;const top=$('#content').scrollTop;
      // Avoid replacing the focused input until typing pauses.
      clearTimeout(state.searchTimer);state.searchTimer=setTimeout(()=>{render(true);const input=$('#searchInput');if(input){input.focus();input.setSelectionRange(pos,pos);$('#content').scrollTop=top;}},170);
    }
    if(e.target.id==='seekSlider') {state.seeking=true;e.target.style.setProperty('--pct',`${e.target.value*100/(Number(e.target.max)||1)}%`);$('#elapsed').textContent=dur(+e.target.value);}
    if(e.target.id==='volumeSlider') {webAudio.volume=+e.target.value;if(native)NativeMusic.setVolume(+e.target.value);}
  });
  document.addEventListener('change',e=>{
    if(e.target.id==='seekSlider') {const ms=+e.target.value;if(native)NativeMusic.seek(ms);else webAudio.currentTime=ms/1000;state.position=ms;state.seeking=false;}
  });
  $('#miniPlayer').addEventListener('click',e=>{if(!e.target.closest('button'))showPlayer();});
  $('#content').addEventListener('scroll',()=>{
    const dock=$('#dock');dock.classList.toggle('compact',$('#content').scrollTop>180 && !!current());
  },{passive:true});
  window.onNativeLibraryChanged=refreshLibrary;
  window.onNativePermissionChanged=granted=>{state.permission=granted;refreshLibrary();};
  window.onNativeResumed=()=>{refreshPlayback();refreshLibrary();};
  window.nativePlaybackError=msg=>toast(msg);
  window.closePlayerIfOpen=()=>{if(state.queueOpen){state.queueOpen=false;$('#queueSheet').classList.remove('open');return true;}if(state.playerOpen){closePlayer();return true;}return false;};
  // Initialize: native device list is real; fictional preview only runs in a regular browser.
  if(native) {state.permission=NativeMusic.hasPermission(); refreshLibrary();refreshPlayback();setInterval(refreshPlayback,550);}
  else {state.songs=demo;state.loaded=true;render();}
})();

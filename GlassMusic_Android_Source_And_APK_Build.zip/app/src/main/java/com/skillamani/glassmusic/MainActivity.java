package com.skillamani.glassmusic;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebResourceRequest;
import android.view.View;
import android.view.WindowManager;

import org.json.JSONArray;
import java.util.ArrayList;
import java.util.List;

/** Trusted local WebView presentation; native Java handles library access and playback. */
public class MainActivity extends Activity {
    private static final int AUDIO_PERMISSION = 720;
    private WebView browser;
    private List<SongCatalog.Song> songs = new ArrayList<>();
    private final Object songsLock = new Object();
    private boolean loading = false;
    private String permissionName() {
        return Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO
                : Manifest.permission.READ_EXTERNAL_STORAGE;
    }
    public boolean hasAudioPermission() {
        return checkSelfPermission(permissionName()) == PackageManager.PERMISSION_GRANTED;
    }
    @SuppressLint({"SetJavaScriptEnabled", "JavascriptInterface"})
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(250,249,252));
        getWindow().setNavigationBarColor(Color.rgb(249,248,251));
        if (Build.VERSION.SDK_INT >= 26) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                    | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);
        }
        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(250,249,252));
        browser.getSettings().setJavaScriptEnabled(true);
        browser.getSettings().setDomStorageEnabled(true);
        browser.getSettings().setAllowFileAccess(true);
        browser.getSettings().setAllowContentAccess(false);
        browser.setOverScrollMode(View.OVER_SCROLL_NEVER);
        browser.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !"file".equals(r.getUrl().getScheme());
            }
        });
        browser.setWebChromeClient(new WebChromeClient());
        browser.addJavascriptInterface(new Bridge(this), "NativeMusic");
        setContentView(browser);
        browser.loadUrl("file:///android_asset/index.html");
        if (hasAudioPermission()) loadSongsAsync();
    }
    private void loadSongsAsync() {
        if (loading || !hasAudioPermission()) return;
        loading = true;
        new Thread(() -> {
            List<SongCatalog.Song> result = SongCatalog.scan(this);
            synchronized (songsLock) { songs = result; }
            loading = false;
            runOnUiThread(() -> notifyJs("window.onNativeLibraryChanged && window.onNativeLibraryChanged()"));
        }, "MusicLibraryScanner").start();
    }
    private void notifyJs(String expression) {
        if (browser != null) browser.evaluateJavascript(expression, null);
    }
    @Override public void onRequestPermissionsResult(int code, String[] p, int[] grants) {
        super.onRequestPermissionsResult(code, p, grants);
        if (code == AUDIO_PERMISSION) {
            if (hasAudioPermission()) loadSongsAsync();
            notifyJs("window.onNativePermissionChanged && window.onNativePermissionChanged(" + hasAudioPermission() + ")");
        }
    }
    @Override protected void onResume() {
        super.onResume();
        if (browser != null) notifyJs("window.onNativeResumed && window.onNativeResumed()");
    }
    @Override public void onBackPressed() {
        if (browser == null) { super.onBackPressed(); return; }
        browser.evaluateJavascript("window.closePlayerIfOpen && window.closePlayerIfOpen()", result -> {
            if (!"true".equals(result)) MainActivity.super.onBackPressed();
        });
    }
    public final class Bridge {
        private final Context context;
        Bridge(Context c) { this.context = c; }
        @JavascriptInterface public boolean hasPermission() { return hasAudioPermission(); }
        @JavascriptInterface public void requestPermission() {
            runOnUiThread(() -> {
                if (!hasAudioPermission()) requestPermissions(new String[]{permissionName()}, AUDIO_PERMISSION);
                else loadSongsAsync();
            });
        }
        @JavascriptInterface public String getSongs() {
            synchronized (songsLock) { return SongCatalog.toJson(songs).toString(); }
        }
        @JavascriptInterface public boolean isScanning() { return loading; }
        @JavascriptInterface public void rescan() { runOnUiThread(() -> loadSongsAsync()); }
        @JavascriptInterface public String getArtwork(long id) {
            SongCatalog.Song song = null;
            synchronized (songsLock) {
                for (SongCatalog.Song s : songs) if (s.id == id) { song = s; break; }
            }
            return SongCatalog.artwork(context, song);
        }
        private void action(String command, long id, int value) {
            runOnUiThread(() -> {
                try { PlayerService.send(context, command, id, value); }
                catch (Exception e) {
                    notifyJs("window.nativePlaybackError && window.nativePlaybackError('Unable to start playback')");
                }
            });
        }
        @JavascriptInterface public void play(long id) { action("play", id, 0); }
        @JavascriptInterface public void pause() { action("pause", -1, 0); }
        @JavascriptInterface public void resume() { action("resume", -1, 0); }
        @JavascriptInterface public void next() { action("next", -1, 0); }
        @JavascriptInterface public void previous() { action("previous", -1, 0); }
        @JavascriptInterface public void seek(int ms) { action("seek", -1, ms); }
        @JavascriptInterface public void shuffle(boolean value) { action("shuffle", -1, value ? 1 : 0); }
        @JavascriptInterface public void repeat(int value) { action("repeat", -1, value); }
        @JavascriptInterface public void setVolume(float value) { action("volume", -1, Math.round(value*100)); }
        @JavascriptInterface public String getState() { return PlayerService.stateJson(); }
    }
}

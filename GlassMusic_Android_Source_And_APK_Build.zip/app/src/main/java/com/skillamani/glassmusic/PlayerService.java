package com.skillamani.glassmusic;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.MediaMetadata;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.SystemClock;

import org.json.JSONObject;
import java.util.List;
import java.util.Random;

/** Foreground-service playback survives leaving the app. No internet connection required. */
public final class PlayerService extends Service {
    public static final String ACTION_COMMAND = "com.skillamani.glassmusic.COMMAND";
    private static final String CHANNEL = "glass_music_playback";
    private static final int NOTICE_ID = 4917;
    private static final long ACTIONS = PlaybackState.ACTION_PLAY | PlaybackState.ACTION_PAUSE
            | PlaybackState.ACTION_PLAY_PAUSE | PlaybackState.ACTION_SKIP_TO_NEXT
            | PlaybackState.ACTION_SKIP_TO_PREVIOUS | PlaybackState.ACTION_SEEK_TO;
    public static volatile PlayerService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Random random = new Random();
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player != null) {
                try { position = player.getCurrentPosition(); } catch (Exception ignored) { }
            }
            handler.postDelayed(this, 450);
        }
    };
    private List<SongCatalog.Song> songs;
    private MediaPlayer player;
    private MediaSession session;
    private AudioManager audioManager;
    private boolean foreground = false;
    private boolean wasPlayingOnDuck = false;
    private int currentIndex = -1;
    public volatile long currentId = -1;
    public volatile boolean playing = false;
    public volatile boolean loading = false;
    public volatile int position = 0;
    public volatile int duration = 0;
    public volatile boolean shuffle = false;
    public volatile int repeat = 0; // 0 off, 1 all, 2 one
    public volatile String error = "";
    public volatile float volume = 1f;

    private final BroadcastReceiver noisyReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context c, Intent i) {
            if (AudioManager.ACTION_AUDIO_BECOMING_NOISY.equals(i.getAction())) pause();
        }
    };
    private final AudioManager.OnAudioFocusChangeListener audioFocus = change -> {
        if (change == AudioManager.AUDIOFOCUS_LOSS) pause();
        else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) {
            wasPlayingOnDuck = playing; pause();
        } else if (change == AudioManager.AUDIOFOCUS_GAIN && wasPlayingOnDuck) {
            wasPlayingOnDuck = false; resume();
        } else if (change == AudioManager.AUDIOFOCUS_LOSS_TRANSIENT_CAN_DUCK && player != null) {
            player.setVolume(volume * .25f, volume * .25f);
        } else if (change == AudioManager.AUDIOFOCUS_GAIN && player != null) {
            player.setVolume(volume, volume);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        audioManager = (AudioManager)getSystemService(AUDIO_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Music playback", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Playback and headset controls");
            getSystemService(NotificationManager.class).createNotificationChannel(channel);
        }
        session = new MediaSession(this, "GlassMusicPlayer");
        session.setFlags(MediaSession.FLAG_HANDLES_MEDIA_BUTTONS | MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
        session.setCallback(new MediaSession.Callback() {
            @Override public void onPlay() { resume(); }
            @Override public void onPause() { pause(); }
            @Override public void onSkipToNext() { next(false); }
            @Override public void onSkipToPrevious() { previous(); }
            @Override public void onSeekTo(long pos) { seek((int)pos); }
            @Override public void onStop() { pause(); }
        });
        session.setActive(true);
        registerReceiver(noisyReceiver, new IntentFilter(AudioManager.ACTION_AUDIO_BECOMING_NOISY));
        updateSession();
        handler.post(ticker);
    }
    public static void send(Context c, String action, long id, int value) {
        Intent i = new Intent(c, PlayerService.class);
        i.setAction(ACTION_COMMAND);
        i.putExtra("command", action);
        i.putExtra("id", id);
        i.putExtra("value", value);
        if (Build.VERSION.SDK_INT >= 26 && ("play".equals(action) || "resume".equals(action)))
            c.startForegroundService(i);
        else c.startService(i);
    }
    @Override public int onStartCommand(Intent i, int flags, int startId) {
        if (i == null) return START_STICKY;
        String action = i.getStringExtra("command");
        if ("play".equals(action) || "resume".equals(action)) {
            // Must post promptly after startForegroundService on modern Android.
            if (!foreground) {
                startForeground(NOTICE_ID, notification());
                foreground = true;
            }
        }
        if (action == null) return START_STICKY;
        switch (action) {
            case "play": playId(i.getLongExtra("id", -1)); break;
            case "resume": resume(); break;
            case "pause": pause(); break;
            case "toggle": if (playing) pause(); else resume(); break;
            case "next": next(false); break;
            case "previous": previous(); break;
            case "seek": seek(i.getIntExtra("value", 0)); break;
            case "shuffle": shuffle = i.getIntExtra("value", 0) == 1; break;
            case "repeat": repeat = i.getIntExtra("value", 0) % 3; break;
            case "volume": volume = Math.max(0f, Math.min(1f, i.getIntExtra("value",100)/100f));
                if (player != null) player.setVolume(volume, volume); break;
            case "stop": pause(); stopSelf(); break;
        }
        return START_STICKY;
    }
    private void ensureSongs() { if (songs == null) songs = SongCatalog.scan(this); }
    public synchronized void playId(long id) {
        ensureSongs();
        for (int n = 0; n < songs.size(); n++) {
            if (songs.get(n).id == id) { playIndex(n); return; }
        }
        error = "Song could not be found in your device library";
    }
    private synchronized void playIndex(int index) {
        ensureSongs();
        if (index < 0 || index >= songs.size()) return;
        currentIndex = index;
        SongCatalog.Song s = songs.get(index);
        currentId = s.id;
        position = 0;
        duration = (int)Math.min(Integer.MAX_VALUE, s.duration);
        playing = false; loading = true; error = "";
        if (player != null) { try { player.release(); } catch (Exception ignored) {} player = null; }
        try {
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            player.setDataSource(this, s.uri);
            player.setVolume(volume, volume);
            player.setOnPreparedListener(p -> {
                loading = false; duration = p.getDuration();
                int focus = audioManager.requestAudioFocus(audioFocus, AudioManager.STREAM_MUSIC, AudioManager.AUDIOFOCUS_GAIN);
                if (focus != AudioManager.AUDIOFOCUS_REQUEST_FAILED) {
                    p.start(); playing = true;
                }
                updateSession(); notifyPlayback();
            });
            player.setOnCompletionListener(p -> {
                playing = false;
                if (repeat == 2) { seek(0); resume(); }
                else next(true);
            });
            player.setOnErrorListener((p, what, extra) -> {
                playing = false; loading = false;
                error = "This audio format could not be played";
                updateSession(); notifyPlayback(); return true;
            });
            player.prepareAsync();
            updateSession(); notifyPlayback();
        } catch (Exception e) {
            playing = false; loading = false;
            error = "Unable to open this audio file";
            updateSession(); notifyPlayback();
        }
    }
    private void resume() {
        if (player != null && !loading) {
            try { player.start(); playing = true; } catch (Exception ignored) { }
        } else if (currentId >= 0 && player == null) playId(currentId);
        updateSession(); notifyPlayback();
    }
    private void pause() {
        if (player != null && playing) {
            try { player.pause(); } catch (Exception ignored) { }
        }
        playing = false; updateSession(); notifyPlayback();
    }
    private void next(boolean fromCompletion) {
        ensureSongs();
        if (songs.isEmpty()) return;
        if (shuffle && songs.size() > 1) {
            int next = random.nextInt(songs.size()-1);
            if (next >= currentIndex) next++;
            playIndex(next); return;
        }
        int next = currentIndex + 1;
        if (next >= songs.size()) {
            if (fromCompletion && repeat == 0) {
                playing = false; position = duration; updateSession(); notifyPlayback(); return;
            }
            next = 0;
        }
        playIndex(next);
    }
    private void previous() {
        ensureSongs();
        if (songs.isEmpty()) return;
        if (position > 3000) { seek(0); return; }
        playIndex((currentIndex - 1 + songs.size()) % songs.size());
    }
    private void seek(int ms) {
        if (player == null || loading) return;
        try {
            int pos = Math.max(0, Math.min(duration, ms));
            player.seekTo(pos); position = pos;
        } catch (Exception ignored) { }
        updateSession();
    }
    public JSONObject state() {
        JSONObject o = new JSONObject();
        try {
            o.put("id", currentId); o.put("playing", playing);
            o.put("loading", loading); o.put("position", position);
            o.put("duration", duration); o.put("shuffle", shuffle);
            o.put("repeat", repeat); o.put("error", error);
        } catch (Exception ignored) { }
        return o;
    }
    public static String stateJson() {
        PlayerService s = instance;
        if (s != null) return s.state().toString();
        return "{\"id\":-1,\"playing\":false,\"position\":0,\"duration\":0,\"shuffle\":false,\"repeat\":0}";
    }
    private SongCatalog.Song current() {
        if (songs != null && currentIndex >= 0 && currentIndex < songs.size()) return songs.get(currentIndex);
        return null;
    }
    private void updateSession() {
        if (session == null) return;
        SongCatalog.Song s = current();
        if (s != null) {
            session.setMetadata(new MediaMetadata.Builder()
                    .putString(MediaMetadata.METADATA_KEY_TITLE, s.title)
                    .putString(MediaMetadata.METADATA_KEY_ARTIST, s.artist)
                    .putString(MediaMetadata.METADATA_KEY_ALBUM, s.album)
                    .putLong(MediaMetadata.METADATA_KEY_DURATION, duration).build());
        }
        session.setPlaybackState(new PlaybackState.Builder().setActions(ACTIONS)
                .setState(playing ? PlaybackState.STATE_PLAYING :
                                loading ? PlaybackState.STATE_BUFFERING : PlaybackState.STATE_PAUSED,
                        position, playing ? 1f : 0f, SystemClock.elapsedRealtime()).build());
    }
    private PendingIntent intentFor(String command, int request) {
        Intent i = new Intent(this, PlayerService.class);
        i.setAction(ACTION_COMMAND); i.putExtra("command", command);
        return PendingIntent.getService(this, request, i, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
    }
    private Notification notification() {
        SongCatalog.Song s = current();
        String title = s != null ? s.title : "Glass Music";
        String artist = s != null ? s.artist : "Your music, beautifully played";
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent activity = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, CHANNEL) : new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(title).setContentText(artist).setContentIntent(activity)
                .setVisibility(Notification.VISIBILITY_PUBLIC)
                .setOngoing(playing).setOnlyAlertOnce(true)
                .addAction(android.R.drawable.ic_media_previous, "Previous", intentFor("previous", 11))
                .addAction(playing ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play,
                        playing ? "Pause" : "Play", intentFor(playing ? "pause" : "resume", 12))
                .addAction(android.R.drawable.ic_media_next, "Next", intentFor("next", 13));
        if (Build.VERSION.SDK_INT >= 21) {
            b.setStyle(new Notification.MediaStyle().setMediaSession(session.getSessionToken())
                    .setShowActionsInCompactView(0, 1, 2));
        }
        return b.build();
    }
    private void notifyPlayback() {
        try { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(NOTICE_ID, notification()); }
        catch (Exception ignored) { }
    }
    @Override public void onDestroy() {
        handler.removeCallbacks(ticker);
        try { unregisterReceiver(noisyReceiver); } catch (Exception ignored) { }
        if (player != null) player.release();
        if (session != null) { session.setActive(false); session.release(); }
        audioManager.abandonAudioFocus(audioFocus);
        if (instance == this) instance = null;
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}

package com.skillamani.glassmusic;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;
import android.util.Base64;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.util.LruCache;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;
import java.util.List;

/** MediaStore-backed offline library: content URIs, not filesystem paths. */
public final class SongCatalog {
    private SongCatalog() {}
    public static class Song {
        public long id, albumId, duration, added;
        public String title, artist, album;
        public Uri uri;
        public JSONObject json() {
            JSONObject o = new JSONObject();
            try {
                o.put("id", id); o.put("title", title); o.put("artist", artist);
                o.put("album", album); o.put("albumId", albumId);
                o.put("duration", duration); o.put("added", added);
            } catch (Exception ignored) {}
            return o;
        }
    }
    private static final LruCache<Long,String> artwork = new LruCache<>(24);
    public static List<Song> scan(Context ctx) {
        List<Song> songs = new ArrayList<>();
        Uri collection = Build.VERSION.SDK_INT >= 29
                ? MediaStore.Audio.Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
                : MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] projection = { MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.DATE_ADDED };
        try (Cursor c = ctx.getContentResolver().query(collection, projection,
                MediaStore.Audio.Media.DURATION + " > 0", null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (c == null) return songs;
            while (c.moveToNext()) {
                Song song = new Song();
                song.id = c.getLong(0);
                song.title = safe(c.getString(1), "Unknown Title");
                song.artist = safe(c.getString(2), "Unknown Artist");
                song.album = safe(c.getString(3), "Unknown Album");
                song.albumId = c.getLong(4);
                song.duration = c.getLong(5);
                song.added = c.getLong(6);
                song.uri = ContentUris.withAppendedId(collection, song.id);
                songs.add(song);
            }
        } catch (SecurityException ignored) { /* request permission in Activity */ }
          catch (Exception ignored) { }
        return songs;
    }
    private static String safe(String s, String fallback) {
        if (s == null || s.trim().isEmpty() || s.equalsIgnoreCase("<unknown>")) return fallback;
        return s;
    }
    public static JSONArray toJson(List<Song> songs) {
        JSONArray result = new JSONArray();
        for (Song s : songs) result.put(s.json());
        return result;
    }
    public static String artwork(Context ctx, Song song) {
        if (song == null) return "";
        synchronized (artwork) {
            String cached = artwork.get(song.albumId);
            if (cached != null) return cached;
        }
        String result = "";
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(ctx, song.uri);
            byte[] raw = retriever.getEmbeddedPicture();
            if (raw != null && raw.length > 0) {
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
                int sample = 1;
                while (Math.max(o.outWidth / sample, o.outHeight / sample) > 480) sample *= 2;
                o = new BitmapFactory.Options(); o.inSampleSize = sample;
                Bitmap bmp = BitmapFactory.decodeByteArray(raw, 0, raw.length, o);
                if (bmp != null) {
                    ByteArrayOutputStream b = new ByteArrayOutputStream();
                    bmp.compress(Bitmap.CompressFormat.JPEG, 78, b);
                    result = "data:image/jpeg;base64," + Base64.encodeToString(b.toByteArray(), Base64.NO_WRAP);
                    bmp.recycle();
                }
            }
        } catch (Exception ignored) { }
        finally { try { retriever.release(); } catch (Exception ignored) { } }
        synchronized (artwork) { artwork.put(song.albumId, result); }
        return result;
    }
}

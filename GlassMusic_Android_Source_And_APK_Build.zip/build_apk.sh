#!/usr/bin/env bash
set -euo pipefail
if ! command -v gradle >/dev/null 2>&1; then
  echo 'Gradle not installed. Install Android Studio, or use .github/workflows/build-apk.yml on GitHub Actions.' >&2
  exit 1
fi
if [[ -z "${ANDROID_HOME:-}" && -z "${ANDROID_SDK_ROOT:-}" ]]; then
  echo 'Set ANDROID_HOME to an Android SDK installation.' >&2
  exit 1
fi
gradle --no-daemon assembleDebug
printf 'APK: app/build/outputs/apk/debug/app-debug.apk\n'
